#include "MKL46Z4.h"                    // Device header
#include "PinDriver.h"
#include "PitTimer.h"
#include "Exercise11_c.h"
#define  LEDTravelTime 200
#define  NumLED        11
#define  Medium				 300
#define	 Hard					 200
#define	 Easy					 400
#define	 Extreme			 100
#define  Button				 23
#define  targetLED		 6
#define  MaxSize			 80
#define  True					 1
#define  False         0
#define  introFlashLen 300
typedef  uint8_t boolean;

